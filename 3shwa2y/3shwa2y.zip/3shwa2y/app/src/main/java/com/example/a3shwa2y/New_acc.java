package com.example.a3shwa2y;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class New_acc extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_acc);
        final EditText User_name=(EditText)findViewById(R.id.U_name);
        final EditText User_email=(EditText)findViewById(R.id.U_email);
        final EditText User_password=(EditText)findViewById(R.id.U_password);
        final Button Reg_done=(Button)findViewById(R.id.reg_Done);


        Reg_done.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
             if(User_name.length()==0){
                 User_name.setError("This is Not option");
             }
              if(User_email.length()==0){
                 User_email.setError("This is Not option");
             }
              if(User_password.length()==0){
                 User_password.setError("This is Not option");
             }
              else {
                  User user = new User(User_name.getText().toString(), User_email.getText().toString(), User_password.getText().toString());
                  DB_Connection db = new DB_Connection(getApplicationContext(), user);
                  db.add();
              }


            }

        });
    }
}
