package com.example.a3shwa2y;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class DB_Connection {
    private String _URL;
    private Context context;
    private User user;
    private Log_in login;
    private boolean object_is_user;
    private boolean object_is_login;
    DB_Connection()
    {

    }
    DB_Connection(Context context){
        _URL="http://192.168.1.7/points/public/api";
        this.context=context;
    }
    DB_Connection(Context context, User user){
        _URL="http://192.168.1.7/points/public/api";
        this.context=context;
        this.user=user;
        object_is_user=true;
    }
    DB_Connection(Context context, Log_in login){
        _URL="http://192.168.1.7/points/public/api";
        this.context=context;
        this.login=login;
        object_is_login=true;
    }
    public void add(){

        RequestQueue requestQueue = Volley.newRequestQueue(context);
        StringRequest postreq=new StringRequest(Request.Method.POST, _URL+'/'+"store",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("Rest Response",response);
                        Toast.makeText(context, "Welcome", Toast.LENGTH_LONG).show();
                        Intent myIntent = new Intent(context, main_page1.class);
                        myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(myIntent);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Rest Response",error.toString() );

                    }
                }
        ){
            @Override



                protected Map<String, String> getParams () {
                Map<String, String> params = new HashMap<String, String>();
           if(object_is_user) {
               params.put("name", user.getU_name());
               params.put("mail", user.getU_Email());
               params.put("password", user.getU_password());
               params.put("status", String.valueOf( user.getU_status()));
           }

                return params;
            }


        };
        requestQueue.add(postreq);
    }
    public void search() {
        String password = "";
        String email="";

        if (object_is_login) {
            password = login.getPassword();
            email=login.getEmail();
        }
        RequestQueue requestQueue = Volley.newRequestQueue(context);

        JsonArrayRequest getRequest = new JsonArrayRequest(Request.Method.GET, _URL + '/' + "search" + '/' + email+'/'+password, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // display response

                        Log.d("Response", response.toString());
                        int  len_of_res=-1;
                        len_of_res=response.length();
                         if(len_of_res==0){
                             Toast.makeText(context,"Email doesn't excist",Toast.LENGTH_LONG).show();
                         }
                         else {

                             Toast.makeText(context, "Welcome", Toast.LENGTH_LONG).show();
                             Intent myIntent = new Intent(context, main_page1.class);
                             myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                             context.startActivity(myIntent);
                         }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );

// add it to the RequestQueue
        requestQueue.add(getRequest);

    }
    public String get_URL() {
        return _URL;
    }

    public void set_URL(String _URL) {
        this._URL = _URL;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public boolean isObject_is_user() {
        return object_is_user;
    }

    public Log_in getLogin() {
        return login;
    }

    public void setLogin(Log_in login) {
        this.login = login;
    }

    public void setObject_is_user(boolean object_is_user) {
        this.object_is_user = object_is_user;
    }

    public boolean isObject_is_login() {
        return object_is_login;
    }

    public void setObject_is_login(boolean object_is_login) {
        this.object_is_login = object_is_login;
    }
}
