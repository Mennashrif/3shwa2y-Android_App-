package com.example.a3shwa2y;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button Creat_new_acc;
    Button Log_in;
    EditText Email;
    EditText Password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Creat_new_acc = (Button) findViewById(R.id.Creat_new_account);
        Log_in=(Button)findViewById(R.id.Log_in);

        Email=(EditText)findViewById(R.id.Mail_edittext);
        Password=(EditText)findViewById(R.id.Password_edittext);

        Creat_new_acc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(getApplicationContext(), New_acc.class);
                startActivity(myIntent);
            }

        });



        Log_in.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Log_in login=new Log_in(Email.getText().toString(),Password.getText().toString());
                DB_Connection db=new DB_Connection(getApplicationContext(),login);
                db.search();

            }
        });
    }
}
