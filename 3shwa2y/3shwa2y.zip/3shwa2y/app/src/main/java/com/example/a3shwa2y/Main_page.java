package com.example.a3shwa2y;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Main_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
    }
}
